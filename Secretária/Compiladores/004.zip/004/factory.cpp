#include "factory.h"

/**
 * This object is automatically registered by the constructor in the
 * superclass' language registry.
 */
udf::factory udf::factory::_self;
