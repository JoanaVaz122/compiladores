UDF compiler (based on CDK).
