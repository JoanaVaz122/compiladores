#include "targets/xml_target.h"

/** @var create and register an XML targets. */
udf::xml_target udf::xml_target::_self;
