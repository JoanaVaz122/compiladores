#include "targets/postfix_target.h"

/**
 * Postfix for ix86.
 * @var create and register an evaluator for ASM targets.
 */
udf::postfix_target udf::postfix_target::_self;
