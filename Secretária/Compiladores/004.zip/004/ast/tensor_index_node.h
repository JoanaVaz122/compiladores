#pragma once

#include <cdk/ast/expression_node.h>
#include <vector>

namespace udf {

  /**
   * Class for describing tensor indexation: t@(i,j,k)
   */
  class tensor_index_node: public cdk::expression_node {
    cdk::expression_node *_tensor;
    std::vector<cdk::expression_node*> _indices;

  public:
    tensor_index_node(int lineno, cdk::expression_node *tensor,
                      std::vector<cdk::expression_node*> indices)
        : cdk::expression_node(lineno), _tensor(tensor), _indices(indices) {}

    cdk::expression_node *tensor() {
      return _tensor;
    }

    const std::vector<cdk::expression_node*> &indices() const {
      return _indices;
    }

    void accept(basic_ast_visitor *sp, int level) {
      sp->do_tensor_index_node(this, level);
    }
  };

}
